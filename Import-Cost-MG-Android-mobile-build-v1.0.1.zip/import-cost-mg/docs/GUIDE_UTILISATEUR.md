# IMPORT COST MG — Guide utilisateur Android

Cette archive contient le moteur de calcul d'origine et une première application Android native.

1. Renseigner les taux payés (fournisseur) et les taux douaniers (déclaration), en MGA par unité de devise.
2. Ajouter un ou plusieurs produits : quantité, prix unitaire, devise, poids, volume, droit et TVA.
3. Saisir les frais communs une seule fois.
4. Calculer, puis enregistrer dans l'historique.
5. Exporter le rapport PDF ou le tableau CSV compatible Excel.

**Important :** vérifier les taux de change douaniers, le code SH, les droits, la TVA et leur date d'effet auprès des Douanes malagasy. Les taux manquants ne sont pas inventés.
