package com.importcostmg.domain

import kotlin.test.*

class EngineTest {
    private val eps = 0.01
    private val rates = ExchangeRates(
        paid = mapOf(Currency.CNY to 600.0, Currency.USD to 4500.0),
        customs = mapOf(Currency.CNY to 620.0, Currency.USD to 4500.0),
    )

    @Test fun volumetricWeight() {
        val d = Dimensions(100.0, 50.0, 40.0) // 200 000 cm³
        assertEquals(200_000.0 / 6000.0, AirFreight.volumetricWeightKg(d), 1e-9)
        assertEquals(40.0, AirFreight.chargeableWeightKg(40.0, d), 1e-9)
    }

    @Test fun chargeableWeightTakesVolumetricWhenHigher() {
        val d = Dimensions(100.0, 50.0, 40.0)
        assertEquals(200_000.0 / 6000.0, AirFreight.chargeableWeightKg(10.0, d), 1e-9)
    }

    @Test fun airFreight() {
        val vol = 200_000.0 / 6000.0
        assertEquals(vol * 50.0, AirFreight.freight(vol, 50.0), 1e-9)
    }

    @Test fun seaFreightUsesMaxOfVolumeAndTonne() {
        val lines = listOf(SeaFreight.PackageLine(10, Dimensions(100.0, 100.0, 100.0), 50.0))
        // volume 10 m³, poids 0,5 t → volume prime
        assertEquals(10.0, SeaFreight.chargeableM3(lines), eps)
        val heavy = listOf(SeaFreight.PackageLine(10, Dimensions(10.0, 10.0, 10.0), 200.0))
        // volume 0,01 m³, poids 2 t → poids prime
        assertEquals(2.0, SeaFreight.chargeableM3(heavy), eps)
    }

    @Test fun currencyConversionUsesPaidAndCustomsRatesSeparately() {
        val r = ExchangeRates(paid = mapOf(Currency.CNY to 600.0), customs = mapOf(Currency.CNY to 620.0))
        assertEquals(6000.0, r.paidRate(Currency.CNY) * 10, eps)
        assertEquals(6200.0, r.customsRate(Currency.CNY) * 10, eps)
        assertEquals(1.0, r.paidRate(Currency.MGA))
    }

    @Test fun allocationSumsExactly() {
        val items = listOf(
            AllocItem("a", 100.0, 1.0, 1.0), AllocItem("b", 200.0, 1.0, 1.0), AllocItem("c", 300.0, 1.0, 1.0),
        )
        val shares = Allocation.allocate(1000.0, items, AllocationKey.VALUE)
        assertEquals(1000.0, shares.values.sum(), 1e-9)
        assertEquals(166.67, shares.getValue("a"), 0.01)
    }

    @Test fun manualAllocationMustTotal100() {
        val items = listOf(AllocItem("a", 1.0, 1.0, 1.0, 60.0), AllocItem("b", 1.0, 1.0, 1.0, 30.0))
        assertFailsWith<IllegalArgumentException> { Allocation.allocate(100.0, items, AllocationKey.MANUAL) }
    }

    @Test fun missingDutyIsFlaggedNotInvented() {
        val p = ProductInput("p1", "Lampe", 10, 5.0, Currency.CNY, 1.0, 0.01, DutyRates(null, 20.0))
        val res = CostEngine.compute(rates, listOf(p), CommonCosts(freightMga = 100_000.0))
        assertFalse(res.verified)
        assertNull(res.products[0].dutyMga)
        assertNull(res.totalImportMga)
        assertTrue("Droit de douane" in res.products[0].missingData)
    }

    @Test fun landedCostHasNoDoubleCounting() {
        // 10 × 5 CNY, taux payé 600 → achat 30 000 MGA
        val p = ProductInput("p1", "Lampe", 10, 5.0, Currency.CNY, 1.0, 0.01, DutyRates(10.0, 20.0))
        val common = CommonCosts(freightMga = 20_000.0, insuranceMga = 1_000.0, portMga = 4_000.0)
        val res = CostEngine.compute(rates, listOf(p), common)
        val r = res.products[0]
        // CIF = achat au taux douanier 10×5×620 = 31 000 + 20 000 + 1 000 = 52 000
        assertEquals(52_000.0, r.customsValueMga, eps)
        assertEquals(5_200.0, r.dutyMga!!, eps)
        // TVA = (52 000 + 5 200) × 20 % = 11 440
        assertEquals(11_440.0, r.vatMga!!, eps)
        // Coût = 30 000 + 20 000 + 1 000 + 4 000 + 5 200 + 11 440 = 71 640
        assertEquals(71_640.0, r.totalCostMga!!, eps)
        assertEquals(7_164.0, r.unitCostMga!!, eps)
        assertTrue(res.verified)
    }

    @Test fun vatRecoverableIsExcluded() {
        val p = ProductInput("p1", "Lampe", 10, 5.0, Currency.CNY, 1.0, 0.01, DutyRates(10.0, 20.0))
        val withVat = CostEngine.compute(rates, listOf(p), CommonCosts(), vatRecoverable = false).products[0].totalCostMga!!
        val noVat = CostEngine.compute(rates, listOf(p), CommonCosts(), vatRecoverable = true).products[0].totalCostMga!!
        assertTrue(withVat > noVat)
    }

    @Test fun margins() {
        val m = Margin.analyse(unitCostMga = 8_000.0, salePriceMga = 10_000.0, quantity = 5)
        assertEquals(2_000.0, m.grossMarginMga, eps)
        assertEquals(25.0, m.marginRatePercent, eps)
        assertEquals(20.0, m.markRatePercent, eps)
        assertEquals(10_000.0, m.totalMarginMga, eps)
        assertEquals(10_000.0, Margin.priceForMarkRate(8_000.0, 20.0), eps)
        assertEquals(10_000.0, Margin.priceForMarginRate(8_000.0, 25.0), eps)
    }

    @Test fun invalidInputIsRejected() {
        assertFailsWith<IllegalArgumentException> { Dimensions(0.0, 1.0, 1.0) }
        assertFailsWith<IllegalArgumentException> { ProductInput("p", "x", 0, 1.0, Currency.USD, 1.0, 0.0, DutyRates(null, null)) }
    }
}
