package com.importcostmg.domain

enum class AllocationKey { VALUE, WEIGHT, VOLUME, MANUAL }

data class AllocItem(
    val id: String,
    val purchaseMga: Double,
    val weightKg: Double,
    val volumeM3: Double,
    val manualShare: Double? = null,   // utilisé si MANUAL, en %
)

/**
 * Répartit un montant commun entre produits. Somme des parts = montant exact
 * (le dernier produit absorbe l'arrondi, sans perte ni doublon).
 */
object Allocation {
    fun allocate(amount: Double, items: List<AllocItem>, key: AllocationKey): Map<String, Double> {
        amount.requireNotNegative("Le montant à répartir ne peut pas être négatif")
        require(items.isNotEmpty()) { "Aucun produit à répartir" }
        val weights: List<Double> = when (key) {
            AllocationKey.VALUE -> items.map { it.purchaseMga }
            AllocationKey.WEIGHT -> items.map { it.weightKg }
            AllocationKey.VOLUME -> items.map { it.volumeM3 }
            AllocationKey.MANUAL -> items.map {
                requireNotNull(it.manualShare) { "Part manuelle manquante pour ${it.id}" }
            }
        }
        val total = weights.sum()
        require(total > 0) { "Base de répartition nulle" }
        if (key == AllocationKey.MANUAL) {
            require(kotlin.math.abs(total - 100.0) < 0.001) { "Les parts manuelles doivent totaliser 100 % (actuel : $total %)" }
        }
        var distributed = 0.0
        val result = LinkedHashMap<String, Double>()
        items.forEachIndexed { i, item ->
            val share = if (i == items.lastIndex) amount - distributed
                        else amount * weights[i] / total
            distributed += share
            result[item.id] = share
        }
        return result
    }
}
