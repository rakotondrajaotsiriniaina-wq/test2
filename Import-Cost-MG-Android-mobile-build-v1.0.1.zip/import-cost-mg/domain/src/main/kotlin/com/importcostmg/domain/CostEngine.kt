package com.importcostmg.domain

/**
 * Coûts communs d'une importation, en MGA. Chaque champ n'est saisi QU'UNE fois.
 * Si le fret ou l'assurance sont déjà inclus dans le prix fournisseur (Incoterm CIF/CFR…),
 * laisser ces champs à 0 : le moteur ne les comptera pas une seconde fois.
 */
data class CommonCosts(
    val freightMga: Double = 0.0,
    val insuranceMga: Double = 0.0,
    val portMga: Double = 0.0,
    val handlingMga: Double = 0.0,
    val transitMga: Double = 0.0,
    val localTransportMga: Double = 0.0,
    val otherMga: Double = 0.0,
) {
    init {
        listOf(freightMga, insuranceMga, portMga, handlingMga, transitMga, localTransportMga, otherMga)
            .forEach { it.requireNotNegative("Un frais ne peut pas être négatif") }
    }
    /** Frais annexes après transport (hors fret et assurance, déjà pris en CIF). */
    val annexMga get() = portMga + handlingMga + transitMga + localTransportMga + otherMga
}

/**
 * Taux douaniers PAR PRODUIT, saisis depuis le tarif officiel ou manuellement.
 * null = donnée manquante : rien n'est inventé, le résultat est marqué « non vérifié ».
 */
data class DutyRates(
    val dutyPercent: Double?,      // droit de douane, sur valeur en douane (CIF)
    val vatPercent: Double?,       // TVA, sur base = CIF + droits + autres taxes
    val otherTaxesMga: Double = 0.0,
    val officialSource: String? = null,
    val validFrom: String? = null,
)

data class ProductInput(
    val id: String,
    val name: String,
    val quantity: Int,
    val unitPrice: Double,           // dans la devise d'achat
    val currency: Currency,
    val weightKg: Double,
    val volumeM3: Double,
    val duty: DutyRates,
    val manualCommonShare: Double? = null,
) {
    init {
        require(quantity > 0) { "La quantité de $name doit être supérieure à 0" }
        require(unitPrice > 0) { "Le prix unitaire de $name doit être supérieur à 0" }
        require(weightKg > 0) { "Le poids de $name doit être supérieur à 0" }
        require(volumeM3 >= 0) { "Le volume de $name ne peut pas être négatif" }
    }
}

data class ProductResult(
    val id: String,
    val name: String,
    val purchaseMga: Double,          // payé au fournisseur (taux payé)
    val customsValueMga: Double,      // valeur en douane (taux douanier)
    val dutyMga: Double?,
    val vatMga: Double?,
    val commonShareMga: Double,
    val totalCostMga: Double?,        // null si taux manquant
    val unitCostMga: Double?,
    val missingData: List<String>,
)

data class ImportResult(
    val products: List<ProductResult>,
    val totalPurchaseMga: Double,
    val totalCommonMga: Double,
    val totalDutyMga: Double?,
    val totalVatMga: Double?,
    val totalImportMga: Double?,
    val verified: Boolean,
)

object CostEngine {

    /**
     * Pipeline :
     * 1. Achat en MGA au taux payé.
     * 2. Valeur en douane = achat au taux douanier + part du fret + assurance (CIF).
     *    Le taux douanier peut différer du taux payé : ce sont deux grandeurs distinctes.
     * 3. Droit = CIF × taux droit. TVA = (CIF + droit + autres taxes) × taux TVA.
     * 4. Coût de revient = achat (taux payé) + fret + assurance + frais annexes + droits + TVA (si non récupérable).
     */
    fun compute(
        rates: ExchangeRates,
        products: List<ProductInput>,
        common: CommonCosts,
        allocationKey: AllocationKey = AllocationKey.VALUE,
        vatRecoverable: Boolean = false,
    ): ImportResult {
        require(products.isNotEmpty()) { "Ajoutez au moins un produit" }
        require(products.map { it.id }.toSet().size == products.size) { "Identifiants de produits en double" }

        val purchase = products.associate { p ->
            p.id to p.quantity * p.unitPrice * rates.paidRate(p.currency)
        }
        val customsPurchase = products.associate { p ->
            p.id to p.quantity * p.unitPrice * rates.customsRate(p.currency)
        }

        val allocItems = products.map {
            AllocItem(
                id = it.id,
                purchaseMga = purchase.getValue(it.id),
                weightKg = it.weightKg * it.quantity,
                volumeM3 = it.volumeM3 * it.quantity,
                manualShare = it.manualCommonShare,
            )
        }
        val freightShare = Allocation.allocate(common.freightMga, allocItems, allocationKey)
        val insuranceShare = Allocation.allocate(common.insuranceMga, allocItems, allocationKey)
        val annexShare = Allocation.allocate(common.annexMga, allocItems, allocationKey)

        val results = products.map { p ->
            val missing = mutableListOf<String>()
            // Valeur en douane (CIF) : achat au taux douanier + fret + assurance. Sert de base au droit uniquement.
            val cif = customsPurchase.getValue(p.id) + freightShare.getValue(p.id) + insuranceShare.getValue(p.id)
            if (p.duty.dutyPercent == null) missing += "Droit de douane"
            if (p.duty.vatPercent == null) missing += "Taux de TVA"
            val duty = p.duty.dutyPercent?.let { cif * it / 100.0 }
            val vat = if (p.duty.vatPercent != null && duty != null)
                (cif + duty + p.duty.otherTaxesMga) * p.duty.vatPercent / 100.0 else null
            val shareOfCommon = freightShare.getValue(p.id) + insuranceShare.getValue(p.id) + annexShare.getValue(p.id)
            // Pas de double comptage : le fret et l'assurance sont dans shareOfCommon, pas ajoutés une seconde fois via le CIF.
            val total = if (duty != null && vat != null) {
                val vatCost = if (vatRecoverable) 0.0 else vat
                purchase.getValue(p.id) + shareOfCommon + duty + p.duty.otherTaxesMga + vatCost
            } else null
            ProductResult(
                id = p.id, name = p.name,
                purchaseMga = purchase.getValue(p.id),
                customsValueMga = cif,
                dutyMga = duty, vatMga = vat,
                commonShareMga = shareOfCommon,
                totalCostMga = total,
                unitCostMga = total?.div(p.quantity),
                missingData = missing,
            )
        }

        val verified = results.all { it.missingData.isEmpty() }
        fun sumIfVerified(select: (ProductResult) -> Double?): Double? =
            if (!verified) null else results.sumOf { select(it) ?: 0.0 }
        val totalDuty = sumIfVerified { it.dutyMga }
        val totalVat = sumIfVerified { it.vatMga }
        val totalImport = sumIfVerified { it.totalCostMga }
        return ImportResult(
            products = results,
            totalPurchaseMga = purchase.values.sum(),
            totalCommonMga = common.freightMga + common.insuranceMga + common.annexMga,
            totalDutyMga = totalDuty,
            totalVatMga = totalVat,
            totalImportMga = totalImport,
            verified = verified,
        )
    }
}
