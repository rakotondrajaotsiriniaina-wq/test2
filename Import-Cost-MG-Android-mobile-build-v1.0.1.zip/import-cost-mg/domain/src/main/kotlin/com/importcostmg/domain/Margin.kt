package com.importcostmg.domain

/** Module commercial. Taux de marge = marge / coût ; taux de marque = marge / prix de vente. */
object Margin {
    data class Result(val grossMarginMga: Double, val marginRatePercent: Double, val markRatePercent: Double, val totalMarginMga: Double)

    fun analyse(unitCostMga: Double, salePriceMga: Double, quantity: Int): Result {
        unitCostMga.requirePositive("Le coût de revient unitaire doit être supérieur à 0")
        salePriceMga.requirePositive("Le prix de vente doit être supérieur à 0")
        require(quantity > 0) { "La quantité à vendre doit être supérieure à 0" }
        val margin = salePriceMga - unitCostMga
        return Result(
            grossMarginMga = margin,
            marginRatePercent = margin / unitCostMga * 100.0,
            markRatePercent = margin / salePriceMga * 100.0,
            totalMarginMga = margin * quantity,
        )
    }

    /** Prix de vente pour obtenir un taux de marge cible (sur coût). */
    fun priceForMarginRate(unitCostMga: Double, targetMarginRatePercent: Double): Double {
        unitCostMga.requirePositive("Le coût de revient unitaire doit être supérieur à 0")
        require(targetMarginRatePercent >= 0) { "La marge cible ne peut pas être négative" }
        return unitCostMga * (1 + targetMarginRatePercent / 100.0)
    }

    /** Prix de vente pour obtenir un taux de marque cible (sur prix de vente). */
    fun priceForMarkRate(unitCostMga: Double, targetMarkRatePercent: Double): Double {
        unitCostMga.requirePositive("Le coût de revient unitaire doit être supérieur à 0")
        require(targetMarkRatePercent in 0.0..99.99) { "Le taux de marque doit être compris entre 0 et 100 %" }
        return unitCostMga / (1 - targetMarkRatePercent / 100.0)
    }
}
