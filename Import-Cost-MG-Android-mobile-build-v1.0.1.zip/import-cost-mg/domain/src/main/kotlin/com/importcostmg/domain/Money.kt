package com.importcostmg.domain

enum class Currency { CNY, USD, EUR, MGA }

/** Taux exprimés en MGA pour 1 unité de devise étrangère. */
data class ExchangeRates(
    val paid: Map<Currency, Double>,     // taux réellement payé au fournisseur
    val customs: Map<Currency, Double>,  // taux douanier applicable à la déclaration
) {
    init {
        (paid.keys + customs.keys).filter { it != Currency.MGA }.forEach { c ->
            require((paid[c] ?: customs[c] ?: 0.0) > 0) { "Taux invalide pour $c" }
        }
    }

    fun paidRate(c: Currency) = if (c == Currency.MGA) 1.0 else requireNotNull(paid[c]) { "Taux payé manquant pour $c" }
    fun customsRate(c: Currency) = if (c == Currency.MGA) 1.0 else requireNotNull(customs[c]) { "Taux douanier manquant pour $c" }
}

fun Double.requirePositive(message: String): Double {
    require(this > 0) { message }
    return this
}

fun Double.requireNotNegative(message: String): Double {
    require(this >= 0) { message }
    return this
}
