package com.importcostmg.domain

import kotlin.math.max

data class Dimensions(val lengthCm: Double, val widthCm: Double, val heightCm: Double) {
    init {
        require(lengthCm > 0 && widthCm > 0 && heightCm > 0) { "Les dimensions doivent être supérieures à 0" }
    }
    val volumeCm3 get() = lengthCm * widthCm * heightCm
}

/** Transport aérien : poids volumétrique et fret. */
object AirFreight {
    /** Diviseur courant (ex. 6000 cm³/kg). Paramètre à confirmer auprès du transporteur. */
    const val DEFAULT_DIVISOR = 6000.0

    fun volumetricWeightKg(d: Dimensions, divisor: Double = DEFAULT_DIVISOR): Double {
        divisor.requirePositive("Le diviseur volumétrique doit être supérieur à 0")
        return d.volumeCm3 / divisor
    }

    fun chargeableWeightKg(realKg: Double, d: Dimensions, divisor: Double = DEFAULT_DIVISOR): Double {
        realKg.requirePositive("Le poids réel doit être supérieur à 0")
        return max(realKg, volumetricWeightKg(d, divisor))
    }

    /** Fret = poids facturable × tarif/kg (devise du tarif). */
    fun freight(chargeableKg: Double, ratePerKg: Double): Double {
        chargeableKg.requirePositive("Le poids facturable doit être supérieur à 0")
        ratePerKg.requireNotNegative("Le tarif au kg ne peut pas être négatif")
        return chargeableKg * ratePerKg
    }
}

/** Transport maritime : volume, poids facturable et fret. */
object SeaFreight {
    /** Une ligne = un type de colis ; quantité × dimensions. */
    data class PackageLine(val count: Int, val dimensions: Dimensions, val weightKgEach: Double) {
        init {
            require(count > 0) { "Le nombre de colis doit être supérieur à 0" }
            require(weightKgEach > 0) { "Le poids par colis doit être supérieur à 0" }
        }
        val volumeM3 get() = dimensions.volumeCm3 * count / 1_000_000.0
        val weightKg get() = weightKgEach * count
    }

    /** Par défaut : le plus grand entre m³ et tonne (1 m³ = 1 000 kg). Règle paramétrable. */
    fun chargeableM3(lines: List<PackageLine>): Double {
        require(lines.isNotEmpty()) { "Ajoutez au moins une ligne de colis" }
        val volume = lines.sumOf { it.volumeM3 }
        val tonnes = lines.sumOf { it.weightKg } / 1000.0
        return max(volume, tonnes)
    }

    fun freight(chargeableM3: Double, ratePerM3: Double): Double {
        chargeableM3.requirePositive("Le volume facturable doit être supérieur à 0")
        ratePerM3.requireNotNegative("Le tarif par m³ ne peut pas être négatif")
        return chargeableM3 * ratePerM3
    }
}
