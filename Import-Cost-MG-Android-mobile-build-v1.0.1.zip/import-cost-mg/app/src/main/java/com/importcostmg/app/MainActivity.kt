package com.importcostmg.app

import android.app.*
import android.os.Bundle
import android.content.*
import android.database.sqlite.*
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.view.*
import android.widget.*
import com.importcostmg.domain.*
import com.importcostmg.domain.Currency as AppCurrency
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class HistoryDb(ctx: Context): SQLiteOpenHelper(ctx, "importcostmg.db", null, 1) {
 override fun onCreate(db: SQLiteDatabase) { db.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT, title TEXT, total REAL, details TEXT)") }
 override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
 fun add(title:String,total:Double,details:String) { writableDatabase.execSQL("INSERT INTO history(created,title,total,details) VALUES(?,?,?,?)", arrayOf(SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.FRANCE).format(Date()),title,total,details)) }
 fun all(): List<String> { val out= mutableListOf<String>(); readableDatabase.rawQuery("SELECT created,title,total FROM history ORDER BY id DESC LIMIT 100",null).use { c-> while(c.moveToNext()) out.add("${c.getString(0)} — ${c.getString(1)} : ${"%,.0f".format(Locale.FRANCE,c.getDouble(2))} Ar") }; return out }
}

class MainActivity : Activity() {
 private lateinit var root: LinearLayout
 private lateinit var name: EditText; private lateinit var qty: EditText; private lateinit var price: EditText; private lateinit var currency: Spinner
 private lateinit var weight: EditText; private lateinit var volume: EditText; private lateinit var duty: EditText; private lateinit var vat: EditText
 private lateinit var freight: EditText; private lateinit var insurance: EditText; private lateinit var port: EditText; private lateinit var handling: EditText; private lateinit var transit: EditText; private lateinit var local: EditText; private lateinit var other: EditText
 private lateinit var cny: EditText; private lateinit var usd: EditText; private lateinit var eur: EditText
 private lateinit var ccny: EditText; private lateinit var cusd: EditText; private lateinit var ceur: EditText
 private lateinit var output: TextView
 private val db by lazy { HistoryDb(this) }
 private val products = mutableListOf<ProductInput>()
 private var lastResult: ImportResult? = null
 private var lastTitle = "Importation"
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi() }
 private fun field(label:String, hint:String="0"): EditText { val wrap=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,4,0,4) }; wrap.addView(TextView(this).apply { text=label; textSize=13f }); val e=EditText(this).apply { this.hint=hint; inputType= android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED; textSize=16f; setSingleLine(true) }; wrap.addView(e); root.addView(wrap); return e }
 private fun section(s:String) { root.addView(TextView(this).apply { text=s; textSize=19f; setTextColor(Color.rgb(18,59,93)); setPadding(0,18,0,6); setTypeface(null,1) }) }
 private fun btn(s:String, action:()->Unit) { root.addView(Button(this).apply { text=s; setOnClickListener { action() } }) }
 private fun buildUi() {
  val scroll=ScrollView(this); root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,16,20,24) }; scroll.addView(root); setContentView(scroll)
  root.addView(TextView(this).apply { text="IMPORT COST MG"; textSize=26f; setTextColor(Color.rgb(18,59,93)); setTypeface(null,1) })
  root.addView(TextView(this).apply { text="Calcul du coût de revient — Importation Madagascar"; textSize=13f })
  section("1. Taux de change (MGA pour 1 unité)")
  cny=field("CNY — taux payé"); usd=field("USD — taux payé"); eur=field("EUR — taux payé")
  ccny=field("CNY — taux douanier"); cusd=field("USD — taux douanier"); ceur=field("EUR — taux douanier")
  btn("Consulter le site officiel des Douanes") { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.douanes.gov.mg/"))) }
  root.addView(TextView(this).apply { text="Mode mixte : saisie manuelle disponible. L'actualisation automatique nécessite une source officielle structurée et vérifiée ; aucun taux n'est prérempli arbitrairement."; textSize=12f })
  section("2. Produit à ajouter")
  name=field("Nom du produit", "Ex. Pompe à eau"); qty=field("Quantité", "1"); price=field("Prix unitaire fournisseur", "0")
  currency=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("CNY","USD","EUR","MGA")) }; root.addView(TextView(this).apply{text="Devise d'achat"}); root.addView(currency)
  weight=field("Poids unitaire (kg)"); volume=field("Volume unitaire (m³)"); duty=field("Droit de douane (%) — vérifier code SH"); vat=field("TVA (%) — vérifier tarif officiel")
  btn("Ajouter ce produit au panier") { addProduct() }
  val productList=TextView(this).apply { text="Aucun produit ajouté"; textSize=13f; tag="products" }; root.addView(productList)
  section("3. Frais communs (MGA)")
  freight=field("Fret total"); insurance=field("Assurance"); port=field("Frais portuaires"); handling=field("Manutention"); transit=field("Transit / commissionnaire"); local=field("Transport local"); other=field("Autres frais")
  section("4. Calcul")
  output=TextView(this).apply { text="Ajoute un produit puis lance le calcul."; textSize=15f; setPadding(0,12,0,12) }; root.addView(output)
  btn("CALCULER LE COÛT DE REVIENT") { calculate() }
  btn("Enregistrer dans l'historique") { saveHistory() }
  btn("Exporter le rapport PDF") { exportPdf() }
  btn("Exporter tableau CSV (ouvrable dans Excel)") { exportCsv() }
  btn("Voir l'historique") { showHistory() }
  btn("Vider les produits") { products.clear(); (root.findViewWithTag<TextView>("products"))?.text="Aucun produit ajouté"; lastResult=null; output.text="Panier vidé." }
  root.addView(TextView(this).apply { text="Version 1.0.0 • Les taux et taux de taxation doivent être confirmés selon la date de déclaration et le code SH. La TVA récupérable n'est pas activée dans cette première interface."; textSize=11f; setPadding(0,18,0,0) })
 }
 private fun num(e:EditText, default:Double=0.0)=e.text.toString().trim().replace(',','.').toDoubleOrNull() ?: default
 private fun addProduct() { try { val n=name.text.toString().ifBlank { "Produit ${products.size+1}" }; val q=qty.text.toString().toInt(); val cur=AppCurrency.valueOf(currency.selectedItem.toString()); val p=ProductInput(UUID.randomUUID().toString(),n,q,num(price),cur,num(weight),num(volume),DutyRates(duty.text.toString().takeIf{it.isNotBlank()}?.replace(',','.')?.toDouble(),vat.text.toString().takeIf{it.isNotBlank()}?.replace(',','.')?.toDouble()))
  products.add(p); root.findViewWithTag<TextView>("products")?.text=products.mapIndexed { i,x -> "${i+1}. ${x.name} × ${x.quantity} (${x.currency})" }.joinToString("\n"); Toast.makeText(this,"Produit ajouté",Toast.LENGTH_SHORT).show()
 } catch(e:Exception) { alert("Vérifie les champs du produit : ${e.message}") } }
 private fun rates():ExchangeRates { val paid=mapOf(AppCurrency.CNY to num(cny),AppCurrency.USD to num(usd),AppCurrency.EUR to num(eur)).filterValues{it>0}; val customs=mapOf(AppCurrency.CNY to num(ccny),AppCurrency.USD to num(cusd),AppCurrency.EUR to num(ceur)).filterValues{it>0}; return ExchangeRates(paid,customs) }
 private fun calculate() { try { val r=CostEngine.compute(rates(),products,CommonCosts(num(freight),num(insurance),num(port),num(handling),num(transit),num(local),num(other))); lastResult=r; lastTitle=name.text.toString().ifBlank { "Importation" }; val lines=r.products.joinToString("\n") { p -> "• ${p.name}: achat ${fmt(p.purchaseMga)} Ar | douane ${p.dutyMga?.let{fmt(it)} ?: "N/V"} | TVA ${p.vatMga?.let{fmt(it)} ?: "N/V"} | revient ${p.unitCostMga?.let{fmt(it)+" Ar/u"} ?: "À compléter"}" }; output.text="${lines}\n\nTotal achats : ${fmt(r.totalPurchaseMga)} Ar\nFrais communs : ${fmt(r.totalCommonMga)} Ar\nDroits : ${r.totalDutyMga?.let{fmt(it)+" Ar"} ?: "NON VÉRIFIÉS"}\nTVA : ${r.totalVatMga?.let{fmt(it)+" Ar"} ?: "NON VÉRIFIÉE"}\nCOÛT TOTAL : ${r.totalImportMga?.let{fmt(it)+" Ar"} ?: "INCOMPLET — renseigner les taux manquants"}\nStatut : ${if(r.verified) "Taux renseignés" else "Données douanières manquantes"}" } catch(e:Exception) { alert("Calcul impossible : ${e.message}") } }
 private fun fmt(v:Double)="%,.0f".format(Locale.FRANCE,v)
 private fun saveHistory() { val r=lastResult ?: run { alert("Lance d'abord le calcul."); return }; val total=r.totalImportMga ?: r.totalPurchaseMga+r.totalCommonMga; db.add(lastTitle,total,output.text.toString()); Toast.makeText(this,"Calcul enregistré",Toast.LENGTH_SHORT).show() }
 private fun showHistory() { val items=db.all(); AlertDialog.Builder(this).setTitle("Historique des importations").setItems(items.toTypedArray(),null).setPositiveButton("Fermer",null).show() }
 private fun exportPdf() { val r=lastResult ?: run { alert("Lance d'abord le calcul."); return }; try { val doc=PdfDocument(); val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create()); val paint=Paint().apply { textSize=12f; color=Color.BLACK }; var y=48; page.canvas.drawText("IMPORT COST MG — Rapport d'importation",36f,y.toFloat(),paint.apply{ textSize=17f; isFakeBoldText=true }); paint.textSize=11f; paint.isFakeBoldText=false; y+=32; output.text.toString().split("\n").forEach { line -> if(y<810){ page.canvas.drawText(line.take(90),36f,y.toFloat(),paint); y+=18 } }; doc.finishPage(page); val f=File(cacheDir,"ImportCostMG-rapport.pdf"); FileOutputStream(f).use{doc.writeTo(it)}; doc.close(); share(f,"application/pdf") } catch(e:Exception){alert("Export PDF : ${e.message}")} }
 private fun exportCsv() { val r=lastResult ?: run { alert("Lance d'abord le calcul."); return }; try { val f=File(cacheDir,"ImportCostMG-produits.csv"); f.writeText("Produit;Quantite;Devise;Achat_MGA;Valeur_douane_MGA;Droit_MGA;TVA_MGA;Cout_total_MGA;Cout_unitaire_MGA\n"+r.products.joinToString("\n"){p-> listOf(p.name,p.id.let{products.find{x->x.id==it}?.quantity?:1},products.find{x->x.id==p.id}?.currency?:"",p.purchaseMga,p.customsValueMga,p.dutyMga?:"",p.vatMga?:"",p.totalCostMga?:"",p.unitCostMga?:"").joinToString(";")}); share(f,"text/csv") } catch(e:Exception){alert("Export CSV : ${e.message}")} }
 private fun share(f:File,mime:String) { val uri=androidx.core.content.FileProvider.getUriForFile(this,"$packageName.fileprovider",f); val intent=Intent(Intent.ACTION_SEND).apply{type=mime; putExtra(Intent.EXTRA_STREAM,uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)}; startActivity(Intent.createChooser(intent,"Exporter le rapport")) }
 private fun alert(s:String) { AlertDialog.Builder(this).setMessage(s).setPositiveButton("OK",null).show() }
}
