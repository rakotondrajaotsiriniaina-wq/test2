plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.importcostmg.app"
    compileSdk = 35
    defaultConfig { applicationId = "com.importcostmg.app"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation(project(":domain")); implementation("androidx.core:core-ktx:1.15.0") }
