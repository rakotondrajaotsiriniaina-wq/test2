# Import Cost MG — projet Android v1.0.0

## Contenu
- `domain/` : moteur Kotlin d'origine conservé (calcul de coût, fret, répartition, marges).
- `app/` : application Android native, formulaire de calcul, panier multi-produits, historique SQLite, export PDF et CSV compatible Excel.
- Min Android : Android 6.0 (API 23).

## Générer l'APK
1. Installer Android Studio : https://developer.android.com/studio
2. Décompresser l'archive puis ouvrir le dossier `import-cost-mg` dans Android Studio.
3. Installer un JDK 17 si Android Studio le demande.
4. Laisser Gradle synchroniser les dépendances (connexion Internet nécessaire).
5. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. L'APK debug est normalement généré dans `app/build/outputs/apk/debug/app-debug.apk`.
7. Copier l'APK sur le téléphone, l'ouvrir et autoriser l'installation depuis cette source si Android le demande.

## Taux de change
Les champs distinguent taux payé au fournisseur et taux douanier. La version actuelle propose la saisie manuelle et un accès au site officiel des Douanes. Elle ne prétend pas télécharger automatiquement un cours officiel : il faut d'abord identifier et valider un flux officiel stable (API ou fichier publié) avant d'automatiser la mise à jour.

## Limites de cette version
- La synchronisation automatique des taux n'est pas activée, faute de source officielle structurée validée.
- Les taux de droits et TVA sont saisis par produit, à confirmer avec le code SH et le tarif en vigueur.
- Export Excel fourni en CSV (ouvrable dans Excel), pas encore en XLSX natif.
- La gestion du catalogue est une saisie multi-produits par calcul ; le catalogue persistant enrichi est à développer.
- L'interface est une première version fonctionnelle, à améliorer après essais sur téléphone.

## Source officielle
Direction générale des Douanes de Madagascar : https://www.douanes.gov.mg/

## Compiler l'APK depuis un téléphone Android (sans ordinateur)

Le dépôt contient un workflow GitHub Actions pour compiler l'APK dans le cloud.

1. Crée un compte sur https://github.com si tu n'en as pas.
2. Dans Chrome sur Android, active si nécessaire « Version pour ordinateur ».
3. Crée un nouveau dépôt GitHub, par exemple `import-cost-mg` (privé ou public).
4. Décompresse l'archive ZIP sur ton téléphone avec l'application Fichiers ou un gestionnaire ZIP.
5. Dans le dépôt GitHub, utilise « Add file » puis « Upload files » et téléverse le contenu du dossier `import-cost-mg` (y compris le dossier caché `.github`).
6. Valide avec « Commit changes » sur la branche `main`.
7. Ouvre l'onglet « Actions », sélectionne « Build Import Cost MG APK », puis « Run workflow » si le lancement automatique n'a pas commencé.
8. Attends que l'exécution soit terminée avec une coche verte.
9. Ouvre l'exécution réussie et télécharge l'artefact `Import-Cost-MG-debug-APK`.
10. Décompresse l'artefact téléchargé : il contient `app-debug.apk`. Ouvre ce fichier pour installer l'application.

Remarques :
- La compilation se fait sur les serveurs GitHub ; aucun ordinateur ni Android Studio n'est nécessaire.
- Le dépôt peut rester privé. Ne publie pas de clés de signature ou de secrets dans le dépôt.
- Il s'agit d'un APK debug destiné aux essais. Pour une diffusion publique, une version release signée sera nécessaire.
- Le premier build peut échouer si une dépendance Android n'est pas disponible ou si une erreur de compilation est détectée ; consulter les journaux de l'exécution dans Actions.
